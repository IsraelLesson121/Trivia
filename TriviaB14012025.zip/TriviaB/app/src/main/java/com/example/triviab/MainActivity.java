package com.example.triviab;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> launcher;

    private FbModule fbModule;
    private String backgroundColor = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fbModule = new FbModule(this);
        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult o) {

                        if (o.getResultCode() == RESULT_OK) {
                            Intent data = o.getData();
                            String str = data.getStringExtra("color");
                            fbModule.writeBeckgroundColorToFb(str);
                            //fbModule.changeBackgroundColorInFireBase(str);

                        }


                    }
                }
        );

    }

    public void onStartGame(View view) {
    }


    public void onSetting(View view) {
        Intent i = new Intent(this, SettingActivity.class);
        launcher.launch(i);
    }


    public void onInstruction(View view) {
    }

    public void setNewColorFromFb(String str) {
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}

